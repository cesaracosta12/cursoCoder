from setuptools import setup

setup(
    author="Cesar Acosta",
    author_email="ocesaracosta@gmail.com",
    description="Setup de entrega2 Curso Python CoderHouse",
    version="0.0.1",
    name="paquete_AcostaCesar_entrega2",
    packages=['paquete','paquete_entrega1']
)